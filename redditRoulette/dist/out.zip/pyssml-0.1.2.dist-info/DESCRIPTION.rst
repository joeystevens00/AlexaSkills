
pyssml

Python 3 SSML builder for Alexa.

Inspired by and based on JavaScript project https://github.com/mandnyc/ssml-builder


