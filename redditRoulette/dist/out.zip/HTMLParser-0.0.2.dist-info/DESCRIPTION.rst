HTMLParser
==========

A copy of HTMLParser from python2.7 for use in python2.6

